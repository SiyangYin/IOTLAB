# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class Lab6P1Config(AppConfig):
    name = 'lab6p1'
